<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\MaterialsSuppliers\\Providers\\MaterialsSuppliersServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\MaterialsSuppliers\\Providers\\MaterialsSuppliersServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);