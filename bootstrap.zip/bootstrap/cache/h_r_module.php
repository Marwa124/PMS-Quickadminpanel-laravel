<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\HR\\Providers\\HRServiceProvider',
    1 => 'Modules\\HR\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\HR\\Providers\\HRServiceProvider',
    1 => 'Modules\\HR\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);