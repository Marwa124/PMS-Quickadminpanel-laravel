<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Finance\\Providers\\FinanceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Finance\\Providers\\FinanceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);