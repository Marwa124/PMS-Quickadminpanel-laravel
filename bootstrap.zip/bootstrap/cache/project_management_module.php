<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ProjectManagement\\Providers\\ProjectManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ProjectManagement\\Providers\\ProjectManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);