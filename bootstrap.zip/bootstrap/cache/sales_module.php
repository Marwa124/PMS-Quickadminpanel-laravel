<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Sales\\Providers\\SalesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Sales\\Providers\\SalesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);